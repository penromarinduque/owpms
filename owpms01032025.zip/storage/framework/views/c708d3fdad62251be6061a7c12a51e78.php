

<?php $__env->startSection('title'); ?>
Specie Families
<?php $__env->stopSection(); ?>

<?php $__env->startSection('species-show'); ?>
show
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-families'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Specie Families</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(url('')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Specie Families</li>
    </ol>
    <div class="card mb-4">
        <div class="card-header">
            <div class="float-end">
                
                <a href="<?php echo e(route('speciefamilies.create')); ?>" class="btn btn-sm btn-primary">Add New</a>
            </div>
            <i class="fas fa-feather-alt me-1"></i>
            List of Specie Families
        </div>
        <div class="card-body">
            <?php if(session('failed')): ?>
            <div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <strong><?php echo e(session('failed')); ?></strong>
            </div>
            <?php endif; ?>

            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <strong><?php echo e(session('success')); ?></strong>
            </div>
            <?php endif; ?>
            <table id="datatablesSimple" class="table table-md table-striped table-hover" id="datatablesSimple">
                <thead>
                    <tr>
                        <th>Specie Family</th>
                        <th>Is Active?</th>
                        <th><i class="fas fa-ellipsis-h" title="Action" alt="Action"></i></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $specie_families; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specie_family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($specie_family->family); ?></td>
                        <td><?php echo e(($specie_family->is_active_family==1) ? 'YES' : 'NO'); ?></td>
                        <td>
                            <a href="<?php echo e(route('speciefamilies.edit', ['id'=>$specie_family->id])); ?>" title="Edit" alt="Edit"><i class="fas fa-edit fa-lg"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\owpms-laravel11\resources\views/admin/maintenance/speciefamilies/index.blade.php ENDPATH**/ ?>