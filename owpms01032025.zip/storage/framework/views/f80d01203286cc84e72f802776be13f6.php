

<?php $__env->startSection('title'); ?>
Add New Permittee
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-permittees'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Add New Permittee</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('permittees.index')); ?>">Permittees</a></li>
        <li class="breadcrumb-item active">Add New</li>
    </ol>

    <div class="card mb-4">
    	<div class="card-header">
            <div class="float-end">
                
                <a href="<?php echo e(route('permittees.index')); ?>" class="btn btn-sm btn-danger"><i class="fas fa-chevron-left"></i> Back</a>
            </div>
            <i class="fas fa-user-plus me-1"></i>
            Add New Permittee here
        </div>
        <div class="card-body">
            <?php if(session('failed')): ?>
            <div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <strong><?php echo e(session('failed')); ?></strong>
            </div>
            <?php endif; ?>

            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <strong><?php echo e(session('success')); ?></strong>
            </div>
            <?php endif; ?>
        	<form method="POST" action="<?php echo e(route('permittees.store')); ?>" onsubmit="disableSubmitButton('btn_save');">
        	<?php echo csrf_field(); ?>
                <h5>Personal Infomation</h5>
        		<div class="row mb-3">
                	<div class="col-sm-4">
                		<label for="last_name" class="form-label mb-0">Lastname<b class="text-danger">*</b></label>
                		<input type="text" class="form-control" name="last_name" id="last_name" placeholder="Lastname" value="<?php echo e(old('last_name')); ?>">
                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                	<div class="col-sm-4">
                		<label for="first_name" class="form-label mb-0">Firstname<b class="text-danger">*</b></label>
                		<input type="text" class="form-control" name="first_name" id="first_name" placeholder="Firstname" value="<?php echo e(old('first_name')); ?>" onkeyup="generateUsername('first_name', 'last_name', 'username');">
                        <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                	<div class="col-sm-4">
                		<label for="middle_name" class="form-label mb-0">Middle Name</label>
                		<input type="text" class="form-control" name="middle_name" id="middle_name" placeholder="Middle Name" value="<?php echo e(old('middle_name')); ?>">
                        <?php $__errorArgs = ['middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                </div>
                <div class="row mb-3">
                	<div class="col-sm-2">
                		<label for="gender" class="form-label mb-0">Gender<b class="text-danger">*</b></label>
                		<select class="form-select" name="gender" id="gender" required>
                			<option value="">-Gender-</option>
                			<option value="male" <?php echo e((old('gender') == 'male') ? 'selected' : ''); ?> >Male</option>
                			<option value="female" <?php echo e((old('gender') == 'female') ? 'selected' : ''); ?>>Female</option>
                		</select>
                        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                	<div class="col-sm-4">
                		<label for="barangay_id" class="form-label mb-0">Address: Barangay / Municipality<b class="text-danger">*</b></label>
                		<select class="form-control select2" name="barangay_id" id="barangay_id" style="width: 100%;" required>
                			<option value="">- Barangay / Municipality -</option>
                			<?php $__empty_1 = true; $__currentLoopData = $barangays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barangay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php $sel_brgy = (old('barangay_id')==$barangay->id) ? 'selected' : ''; ?>
                			<option value="<?php echo e($barangay->id); ?>" <?php echo e($sel_brgy); ?>><?php echo e($barangay->barangay_name.' / '.$barangay->municipality_name.' / '.$barangay->province_name); ?></option>
                			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                			<?php endif; ?>
                		</select>
                        <?php $__errorArgs = ['barangay_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                    <div class="col-sm-2">
                        <label for="contact_no" class="form-label mb-0">Contact Number<b class="text-danger">*</b></label>
                        <input type="text" class="form-control" name="contact_no" id="contact_no" placeholder="Contact Number" value="<?php echo e(old('contact_no')); ?>">
                        <?php $__errorArgs = ['contact_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-3">
                        <label for="email" class="form-label mb-0">Email<b class="text-danger">*</b></label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                	<!-- <div class="col-sm-4">
                		<label for="business_name" class="form-label mb-0">Business Name</label>
                		<input type="text" class="form-control" name="business_name" id="business_name" placeholder="Business Name" value="<?php echo e(old('business_name')); ?>">
                        <?php $__errorArgs = ['business_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div> -->
                </div>
                <hr>
                <h5>Wildlife Farm and Permit Details</h5>
                <div class="row mb-3">
                    <div class="col-sm-4">
                        <label for="farm_name">Farm Name<b class="text-danger">*</b></label>
                        <input type="text" class="form-control" name="farm_name" id="farm_name" placeholder="Farm Name" value="<?php echo e(old('farm_name')); ?>">
                        <?php $__errorArgs = ['farm_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-4">
                        <label for="location" class="form-label mb-0">Location<b class="text-danger">*</b></label>
                        <select class="form-control select2" name="location" id="location" style="width: 100%;" required>
                            <option value="">- Barangay / Municipality -</option>
                            <?php $__empty_1 = true; $__currentLoopData = $barangays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barangay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php $sel_brgy = (old('location')==$barangay->id) ? 'selected' : ''; ?>
                            <option value="<?php echo e($barangay->id); ?>" <?php echo e($sel_brgy); ?>><?php echo e($barangay->barangay_name.' / '.$barangay->municipality_name.' / '.$barangay->province_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </select>
                        <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-2">
                        <label for="size">Size<b class="text-danger">*</b></label>
                        <input type="text" class="form-control" name="size" id="size" placeholder="Size" value="<?php echo e(old('size')); ?>">
                        <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-2">
                        <label for="height">Height<b class="text-danger">*</b></label>
                        <input type="text" class="form-control" name="height" id="height" placeholder="Height" value="<?php echo e(old('height')); ?>">
                        <?php $__errorArgs = ['height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <input type="hidden" name="permit_type_wfp" id="permit_type_wfp" value="wfp">
                    <div class="col-sm-3">
                        <label for="permit_number_wfp">Permit Number<b class="text-danger">*</b></label>
                        <input type="text" class="form-control" name="permit_number_wfp" id="permit_number_wfp" placeholder="Permit Number" value="<?php echo e(old('permit_number_wfp')); ?>">
                        <?php $__errorArgs = ['permit_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-2">
                        <label for="valid_from_wfp">Valid from<b class="text-danger">*</b></label>
                        <input type="date" class="form-control" name="valid_from_wfp" id="valid_from_wfp" placeholder="Valid from" value="<?php echo e(old('valid_from_wfp')); ?>">
                        <?php $__errorArgs = ['valid_from_wfp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-2">
                        <label for="valid_to_wfp">Valid to<b class="text-danger">*</b></label>
                        <input type="date" class="form-control" name="valid_to_wfp" id="valid_to_wfp" placeholder="Valid to" value="<?php echo e(old('valid_to_wfp')); ?>">
                        <?php $__errorArgs = ['valid_to_wfp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-2">
                        <label for="date_of_issue_wfp">Date of Issue<b class="text-danger">*</b></label>
                        <input type="date" class="form-control" name="date_of_issue_wfp" id="date_of_issue_wfp" placeholder="Date of Issue" value="<?php echo e(old('date_of_issue')); ?>">
                        <?php $__errorArgs = ['date_of_issue_wfp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <hr>
                <h5>Wildlife Collection Permit Details</h5>
                <div class="row mb-3">
                    <input type="hidden" name="permit_type_wcp" id="permit_type_wcp" value="wcp">
                    <div class="col-sm-3">
                        <label for="permit_number_wcp">Permit Number<b class="text-danger">*</b></label>
                        <input type="text" class="form-control" name="permit_number_wcp" id="permit_number_wcp" placeholder="Permit Number" value="<?php echo e(old('permit_number_wcp')); ?>">
                        <?php $__errorArgs = ['permit_number_wcp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-2">
                        <label for="valid_from_wcp">Valid from<b class="text-danger">*</b></label>
                        <input type="date" class="form-control" name="valid_from_wcp" id="valid_from_wcp" placeholder="Valid from" value="<?php echo e(old('valid_from_wcp')); ?>">
                        <?php $__errorArgs = ['valid_from_wcp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-2">
                        <label for="valid_to_wcp">Valid to<b class="text-danger">*</b></label>
                        <input type="date" class="form-control" name="valid_to_wcp" id="valid_to_wcp" placeholder="Valid to" value="<?php echo e(old('valid_to_wcp')); ?>">
                        <?php $__errorArgs = ['valid_to_wcp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-2">
                        <label for="date_of_issue_wcp">Date of Issue<b class="text-danger">*</b></label>
                        <input type="date" class="form-control" name="date_of_issue_wcp" id="date_of_issue_wcp" placeholder="Date of Issue" value="<?php echo e(old('date_of_issue_wcp')); ?>">
                        <?php $__errorArgs = ['date_of_issue_wcp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <hr>
                <h5>Login Credentials</h5>
                <div class="row mb-3">
                    <div class="col-sm-3">
                        <label for="username" class="form-label mb-1">Username<b class="text-danger">*</b></label>
                        <!-- <button type="button" class="btn btn-sm btn-secondary" onclick="generateUsername('firstname', 'lastname', 'username');">Generate</button> -->
                        <input type="text" class="form-control" name="username" id="username" placeholder="Username" value="<?php echo e(old('username')); ?>" readonly>
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-3">
                        <label for="password" class="form-label mb-1">Password<b class="text-danger">*</b></label>
                        <input id="gen_passw" type="checkbox" onclick="genaratePassword('gen_passw', 'password');" />
                        <label for="gen_passw" class="form-label mb-1">Generate</label>
                        <div class="input-group mb-3">
                            <input type="password" name="password" id="password" class="form-control" aria-label="Text input with checkbox">
                            <div class="input-group-text">
                                <input class="form-check-input mt-0" type="checkbox" id="show_passw" aria-label="Checkbox for following text input" onclick="showPass('show_passw', 'password');">
                                <label for="show_passw">Show</label>
                            </div>
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <hr>
                <button type="submit" id="btn_save" class="btn btn-primary btn-block float-end"><i class="fas fa-save"></i> Save Permittee</button>
        	</form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-extra'); ?>
<script type="text/javascript">

    function generateUsername2(fname_fld, lname_fld, mname_fld, uname_fld) {
        var fname = document.getElementById(fname_fld).value;
        var nameList = [
          fname,
          document.getElementById(lname_fld).value,
          document.getElementById(mname_fld).value,
        ];

        var userName = "";

        userName = nameList[Math.floor( Math.random() * nameList.length )];
        userName += nameList[Math.floor( Math.random() * nameList.length )];
        if ( Math.random() > 0.5 ) {
            userName += nameList[Math.floor( Math.random() * nameList.length )];
        }

        var str_u = fname;
        str_u = str_u.replace(/ +/g, "");
        // return "owpms_" + userName;
        // Array.from('some string')[0];
        // console.log(Array.from('some string')[0]);
        document.getElementById(uname_fld).value = "owpms_" + str_u.toLowerCase();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\owpms-laravel11\resources\views/admin/permittee/create.blade.php ENDPATH**/ ?>