<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo $__env->yieldContent('title'); ?> | PENRO Marinduque - Online Wildlife Permitting and Management System (OWPMS)</title>
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('images/logo-icon.ico')); ?>" sizes="16x16 32x32">
        <link href="<?php echo e(asset('assets/fontawesome-free-6.5.1-web/css/fontawesome.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('assets/simple-datatables/style.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" />
        <!-- Select2 -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/select2/dist/css/select2.min.css')); ?>">
        <link href="<?php echo e(asset('css/customize.css')); ?>" rel="stylesheet" />
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <?php echo $__env->make('layouts.navtop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <?php echo $__env->make('layouts.navside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; DENR - PENRO Marinduque 2024</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <!-- jQuery -->
        <script src="<?php echo e(asset('assets/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js')); ?>" crossorigin="anonymous"></script>
        <script src="<?php echo e(asset('assets/fontawesome-free-6.5.1-web/js/all.min.js')); ?>" crossorigin="anonymous"></script>
        <!-- Select2 -->
        <script src="<?php echo e(asset('assets/select2/dist/js/select2.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.ajaxrequestlaravel.js')); ?>" defer></script>
        <script type="text/javascript">
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        </script>
        <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
        <script src="<?php echo e(asset('js/extra.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/simple-datatables/simple-datatables.min.js')); ?>" crossorigin="anonymous"></script>
        <script src="<?php echo e(asset('js/datatables-simple-demo.js')); ?>"></script>
        <script type="text/javascript"> 
            var $ = jQuery.noConflict();
            jQuery(document).ready(function ($){

                // Select2
                $(".select2").select2();
            });
        </script>
        <!-- on page scripts -->
        <?php echo $__env->yieldContent('script-extra'); ?>
    </body>
</html>
<?php /**PATH C:\Apache24\htdocs\owpms-laravel11\resources\views/layouts/master.blade.php ENDPATH**/ ?>