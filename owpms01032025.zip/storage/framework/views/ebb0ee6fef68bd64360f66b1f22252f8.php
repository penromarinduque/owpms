

<?php $__env->startSection('title'); ?>
Permit Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-permittees'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Permit Details</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item">Permittees</li>
        <li class="breadcrumb-item active">Permit Details</li>
    </ol>
    <div class="card mb-4">
    	<div class="card-header">
            <div class="float-end">
                <a href="<?php echo e(route('permittees.create')); ?>" class="btn btn-sm btn-primary"><i class="fas fa-user-plus"></i> Add New</a>
            </div>
            <i class="fas fa-file me-1"></i>
            Permit Details
        </div>
        <div class="card-body">
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-extra'); ?>
<script type="text/javascript">
    // function showDetails(id, show_to) {
    //     $(this).ajaxRequestLaravel({
    //         show_result: ['/permittees/show/'+id, show_to],
    //         show_result_loader: true,
    //     });
    // }

    function ajaxUpdateStatus(chkbox_id, permittee_id) {
        var chkd = $('#'+chkbox_id).is(':checked');
        var stat = 0;
        if (chkd) {
            stat = 1;
        }
        // console.log(stat);
        $.ajax({
            type: 'POST',
            url: "<?php echo e(route('permittees.ajaxupdatestatus')); ?>",
            data: {permittee_id:permittee_id, is_active_permittee:stat},
            success: function (result){
                // console.log(result);
            },
            error: function (result){
                // console.log(result);
                alert('Oops! Something went wrong. Please reload the page and try again.');
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\owpms-laravel11\resources\views/admin/permittee/show.blade.php ENDPATH**/ ?>