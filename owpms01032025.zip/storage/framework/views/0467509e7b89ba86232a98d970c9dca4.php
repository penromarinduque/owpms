

<?php $__env->startSection('title'); ?>
Permittees
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-permittees'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Permittees</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Permittees</li>
    </ol>
    <div class="card mb-4">
    	<div class="card-header">
            <div class="float-end">
                <a href="<?php echo e(route('permittees.create')); ?>" class="btn btn-sm btn-primary"><i class="fas fa-user-plus"></i> Add New</a>
            </div>
            <i class="fas fa-users me-1"></i>
            List of Permittees
        </div>
        <div class="card-body">
            <?php if(session('failed')): ?>
            <div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <strong><?php echo e(session('failed')); ?></strong>
            </div>
            <?php endif; ?>

            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <strong><?php echo e(session('success')); ?></strong>
            </div>
            <?php endif; ?>
            <table class="table table-sm" id="datatablesSimple">
                <thead>
                    <tr>
                        <th>Permittee</th>
                        <th>Gender</th>
                        <th>Address</th>
                        <th>Contact No</th>
                        <th>Email</th>
                        <th>WFP/WCP Permit Numbers</th>
                        <th>Active</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $permittees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permittee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(strtoupper($permittee->last_name.', '.$permittee->first_name.' '.$permittee->middle_name)); ?></td>
                        <td><?php echo e(strtoupper($permittee->gender)); ?></td>
                        <td><?php echo e($permittee->barangay_name.', '.$permittee->municipality_name.', '.$permittee->province_name); ?></td>
                        <td><?php echo e($permittee->contact_no); ?></td>
                        <td><?php echo e($permittee->email); ?></td>
                        <td>
                        <?php if(!empty($permittee->wildlifePermits)): ?>
                            <?php $__currentLoopData = $permittee->wildlifePermits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wildlifepermit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('permittees.show', [$wildlifepermit->id])); ?>" title="View Deatils"><?php echo e(strtoupper($wildlifepermit->permit_number)); ?></a><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </td>
                        <td>
                            <div class="form-check form-switch">
                              <input class="form-check-input" type="checkbox" role="switch" id="chkActiveStat<?php echo e($permittee->id); ?>" onclick="ajaxUpdateStatus('chkActiveStat<?php echo e($permittee->id); ?>', '<?php echo e(Crypt::encrypt($permittee->id)); ?>');" <?php echo e(($permittee->is_active_permittee==1) ? 'checked' : ''); ?>>
                            </div>
                        </td>
                        <td>
                            <a href="<?php echo e(route('permittees.edit', ['id'=>Crypt::encrypt($permittee->id)])); ?>" title="Edit" alt="Edit"><i class="fas fa-edit fa-lg"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-extra'); ?>
<script type="text/javascript">
    // function showDetails(id, show_to) {
    //     $(this).ajaxRequestLaravel({
    //         show_result: ['/permittees/show/'+id, show_to],
    //         show_result_loader: true,
    //     });
    // }

    function ajaxUpdateStatus(chkbox_id, permittee_id) {
        var chkd = $('#'+chkbox_id).is(':checked');
        var stat = 0;
        if (chkd) {
            stat = 1;
        }
        // console.log(stat);
        $.ajax({
            type: 'POST',
            url: "<?php echo e(route('permittees.ajaxupdatestatus')); ?>",
            data: {permittee_id:permittee_id, is_active_permittee:stat},
            success: function (result){
                // console.log(result);
            },
            error: function (result){
                // console.log(result);
                alert('Oops! Something went wrong. Please reload the page and try again.');
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\owpms-laravel11\resources\views/admin/permittee/index.blade.php ENDPATH**/ ?>