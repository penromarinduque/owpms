

<?php $__env->startSection('title'); ?>
LTP Requirements
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-ltprequirements'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">LTP Requirements</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(url('')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item">Maintenance</li>
        <li class="breadcrumb-item active">LTP Requirements</li>
    </ol>
    <div class="card mb-4">
    	<div class="card-header">
            <div class="float-end">
                <a href="<?php echo e(route('ltprequirements.create')); ?>" class="btn btn-sm btn-primary">Add New</a>
            </div>
            <i class="fas fa-list me-1"></i>
            List of LTP Requirements
        </div>
        <div class="card-body">
            <?php if(session('failed')): ?>
            <div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <strong><?php echo e(session('failed')); ?></strong>
            </div>
            <?php endif; ?>

            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <strong><?php echo e(session('success')); ?></strong>
            </div>
            <?php endif; ?>
            <table id="datatablesSimple" class="table table-md table-striped table-hover" id="datatablesSimple">
                <thead>
                    <tr>
                        <th>Requirement</th>
                        <th>Is Mandatory?</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                	<?php $__empty_1 = true; $__currentLoopData = $ltprequirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ltprequirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($ltprequirement->requirement_name); ?></td>
                        <td><?php echo e(($ltprequirement->is_mandatory==1) ? 'YES' : 'NO'); ?></td>
                        <td><?php echo e(($ltprequirement->is_active_requirement==1) ? 'Active' : 'Inactive'); ?></td>
                        <td>
                            <a href="<?php echo e(route('ltprequirements.edit', ['id'=>$ltprequirement->id])); ?>" title="Edit" alt="Edit"><i class="fas fa-edit fa-lg"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\owpms-laravel11\resources\views/admin/maintenance/ltprequirements/index.blade.php ENDPATH**/ ?>