

<?php $__env->startSection('title'); ?>
Edit Specie
<?php $__env->stopSection(); ?>

<?php $__env->startSection('species-show'); ?>
show
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-species'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Edit Specie</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('species.index')); ?>">Species</a></li>
        <li class="breadcrumb-item active">Edit</li>
    </ol>
    <div class="card mb-4">
    	<div class="card-header">
            <div class="float-end">
                
                <a href="<?php echo e(route('species.index')); ?>" class="btn btn-sm btn-danger"><i class="fas fa-chevron-left"></i> Back</a>
            </div>
            <i class="fas fa-edit me-1"></i>
            Edit Specie here
        </div>
        <div class="card-body">
            <?php if(!empty($specie)): ?>
            <form method="POST" action="<?php echo e(route('species.update', [Crypt::encrypt($specie_id)])); ?>" onsubmit="disableSubmitButton('btn_update');">
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                	<div class="col-sm-4">
                		<label for="specie_type_id" class="form-label">Specie Type</label>
                		<select class="form-select" name="specie_type_id" id="specie_type_id">
                			<option value="">- Please Select Type-</option>
                            <?php $__empty_1 = true; $__currentLoopData = $specie_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specie_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($specie_type->id); ?>" <?php echo e(($specie_type->id==$specie->specie_type_id) ? 'selected' : ''); ?>><?php echo e($specie_type->specie_type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                		</select>
                        <?php $__errorArgs = ['specie_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                	<div class="col-sm-4">
                		<label for="specie_class_id" class="form-label">Specie Class</label>
                		<select class="form-select" name="specie_class_id" id="specie_class_id">
                			<option value="">- Please Select Class -</option>
                            <?php $__empty_1 = true; $__currentLoopData = $specie_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specie_class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($specie_class->id); ?>" <?php echo e(($specie_class->id==$specie->specie_class_id) ? 'selected' : ''); ?>><?php echo e($specie_class->specie_class); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                		</select>
                        <?php $__errorArgs = ['specie_class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                	<div class="col-sm-4">
                		<label for="specie_family_id" class="form-label">Specie Family</label>
                		<select class="form-select" name="specie_family_id" id="specie_family_id">
                			<option value="">- Please Select Family -</option>
                            <?php $__empty_1 = true; $__currentLoopData = $specie_families; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specie_family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($specie_family->id); ?>" <?php echo e(($specie_family->id==$specie->specie_family_id) ? 'selected' : ''); ?>><?php echo e($specie_family->family); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                		</select>
                        <?php $__errorArgs = ['specie_family_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                </div>
                <div class="row mb-3">
                	<div class="col-sm-5">
                		<label for="specie_name" class="form-label">Scientific Name</label>
                		<input type="text" class="form-control" name="specie_name" id="specie_name" placeholder="Scientific Name" value="<?php echo e($specie->specie_name); ?>">
                        <?php $__errorArgs = ['specie_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                	<div class="col-sm-2 pt-4">
                      	<input type="checkbox" id="present" name="present" <?php echo e(($specie->is_present==1) ? 'checked' : ''); ?>>
                       	<label for="present" style="margin-bottom: 0px;">Present</label> 
                       	<span style="font-size: 10px;"><br>Check if this specie is present in this Province</span>
                	</div>
                	<div class="col-sm-5">
                		<label for="local_name" class="form-label">Common/Local Name</label>
                		<input type="text" class="form-control" name="local_name" id="local_name" placeholder="Common/Local Name" value="<?php echo e($specie->local_name); ?>">
                        <?php $__errorArgs = ['local_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                </div>
                <div class="row mb-3">
                	<div class="col-sm-4">
                        <label for="wing_span" class="form-label">Wing Span (ave.) - (If Applicable)</label>
                        <input type="text" class="form-control" name="wing_span" id="wing_span" placeholder="Wing Span (ave.)" value="<?php echo e($specie->wing_span); ?>">
                    </div>
                	<div class="col-sm-4">
                        <label for="wing_span" class="form-label">Convservation Status:</label> <br>
                        <input type="radio" value="rare" id="rare" name="conservation_status" <?php echo e(($specie->conservation_status=='rare') ? 'checked' : ''); ?> >
                        <label for="rare">Rare</label> &nbsp;
                        <input type="radio" value="threatened" id="threatened" name="conservation_status" <?php echo e(($specie->conservation_status=='threatened') ? 'checked' : ''); ?>>
                        <label for="threatened">Threatened</label> &nbsp;
                        <input type="radio" value="vulnerable" id="vulnerable" name="conservation_status" <?php echo e(($specie->conservation_status=='vulnerable') ? 'checked' : ''); ?>>
                        <label for="vulnerable">Vulnerable</label> &nbsp;
                        <?php $__errorArgs = ['conservation_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                	<div class="col-sm-4"></div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-6">
                        <label for="color_description" class="form-label">Color Description</label>
                        <textarea class="form-control" name="color_description" id="color_description"><?php echo e($specie->color_description); ?></textarea>
                        <?php $__errorArgs = ['color_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-6">
                        <label for="food_plant" class="form-label">Food Plant</label>
                        <textarea class="form-control" name="food_plant" id="food_plant"><?php echo e($specie->food_plant); ?></textarea>
                        <?php $__errorArgs = ['food_plant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <button type="submit" id="btn_update" class="btn btn-primary btn-block float-end"><i class="fas fa-save"></i> Save Changes</button>
            </form>
            <?php else: ?>
            <center>
                <h5 class="text-danger">No record found!</h5>
            </center>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\owpms-laravel11\resources\views/admin/species/edit.blade.php ENDPATH**/ ?>