

<?php $__env->startSection('title'); ?>
Create Position
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-positions'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Add New Position</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('positions.index')); ?>">Positions</a></li>
        <li class="breadcrumb-item active">Add New</li>
    </ol>
    <div class="card mb-4">
    	<div class="card-header">
            <div class="float-end">
                
                <a href="<?php echo e(route('positions.index')); ?>" class="btn btn-sm btn-danger">Back</a>
            </div>
            <i class="fas fa-plus-square me-1"></i>
            Add New Position here
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('positions.store')); ?>" onsubmit="disableSubmitButton('btn_save');">
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                	<div class="col-sm-6">
                		<label for="position" class="form-label">Position</label>
	                    <input type="text" class="form-control" name="position" id="position" value="<?php echo e(old('position')); ?>">
	                    <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                    <small class="text-danger"><?php echo e($message); ?></small>
	                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                    <div class="col-sm-6">
                		<label for="description" class="form-label">Description <i>(optional)</i></label>
	                    <textarea class="form-control" name="description" id="description"><?php echo e(old('description')); ?></textarea>
	                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                    <small class="text-danger"><?php echo e($message); ?></small>
	                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                </div>
                <button type="submit" id="btn_save" class="btn btn-primary btn-block float-end">Save</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\owpms-laravel11\resources\views/admin/maintenance/positions/create.blade.php ENDPATH**/ ?>