

<?php $__env->startSection('title'); ?>
Species
<?php $__env->stopSection(); ?>

<?php $__env->startSection('species-show'); ?>
show
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-species'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Species</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Species</li>
    </ol>
    <div class="card mb-4">
    	<div class="card-header">
            <div class="float-end">
                <a href="<?php echo e(route('species.create')); ?>" class="btn btn-sm btn-primary">Add New</a>
            </div>
            <i class="fas fa-feather me-1"></i>
            List of Species
        </div>
        <div class="card-body">
            <?php if(session('failed')): ?>
            <div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <strong><?php echo e(session('failed')); ?></strong>
            </div>
            <?php endif; ?>

            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <strong><?php echo e(session('success')); ?></strong>
            </div>
            <?php endif; ?>
            
            <table class="table table-sm" id="datatablesSimple">
                <thead>
                    <tr>
                        <th>Scientific Name</th>
                        <th>Common/Local Name</th>
                        <th>Type/Class/Family</th>
                        <th>Is present in this Province?</th>
                        <th>Active</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $species; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($specie->specie_name); ?></td>
                        <td><a href="#modalDetails" data-bs-toggle="modal" onclick="showDetails('<?php echo e(Crypt::encrypt($specie->id)); ?>', 'specie_details');"><?php echo e($specie->local_name); ?></a></td>
                        <td><?php echo e($specie->specie_type.'/'.$specie->specie_class.'/'.$specie->family); ?></td>
                        <td><?php echo e(($specie->is_present==1) ? 'YES' : 'NO'); ?></td>
                        <td>
                            <div class="form-check form-switch">
                              <input class="form-check-input" type="checkbox" role="switch" id="chkActiveStat<?php echo e($specie->id); ?>" onclick="ajaxUpdateStatus('chkActiveStat<?php echo e($specie->id); ?>', '<?php echo e(Crypt::encrypt($specie->id)); ?>');" <?php echo e(($specie->is_active_specie==1) ? 'checked' : ''); ?>>
                              <!-- <label class="form-check-label" for="flexSwitchCheckChecked">Checked switch checkbox input</label> -->
                            </div>
                        </td>
                        <td>
                            <a href="<?php echo e(route('species.edit', ['id'=>Crypt::encrypt($specie->id)])); ?>" title="Edit" alt="Edit"><i class="fas fa-edit fa-lg"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal show details -->
<div class="modal fade" id="modalDetails" tabindex="-1" aria-labelledby="modalDetailsLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div id="specie_details"></div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-extra'); ?>
<script type="text/javascript">
    function showDetails(id, show_to) {
        $(this).ajaxRequestLaravel({
            show_result: ['/species/show/'+id, show_to],
            show_result_loader: true,
        });
    }

    function ajaxUpdateStatus(chkbox_id, specie_id) {
        var chkd = $('#'+chkbox_id).is(':checked');
        var stat = 0;
        if (chkd) {
            stat = 1;
        }
        // console.log(stat);
        $.ajax({
            type: 'POST',
            url: "<?php echo e(route('species.ajaxupdatestatus')); ?>",
            data: {specie_id:specie_id, is_active_specie:stat},
            success: function (result){
                // console.log(result);
            },
            error: function (result){
                // console.log(result);
                alert('Oops! Something went wrong. Please reload the page and try again.');
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\owpms-laravel11\resources\views/admin/species/index.blade.php ENDPATH**/ ?>