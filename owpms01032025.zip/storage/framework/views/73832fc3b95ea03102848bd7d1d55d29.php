

<?php $__env->startSection('content'); ?>
<div class="card shadow-lg border-1 rounded-lg mt-1">
    <div class="card-header"><h3 class="text-center font-weight-light my-4"><i class="fas fa-lock"></i> Login</h3></div>
    <div class="card-body">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session()->get('error')); ?>

            </div>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('login.store')); ?>" onsubmit="disableSubmitBtn('btn_login');">
            <?php echo csrf_field(); ?>
            <div class="form-floating mb-3">
                <input class="form-control" name="username" id="username" type="text" placeholder="Username" value="<?php echo e(old('username')); ?>" />
                <label for="username">Username</label>
                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-floating mb-3">
                <input class="form-control" name="password" id="password" type="password" placeholder="Password" />
                <label for="password">Password</label>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-check mb-1">
                <input class="form-check-input" type="checkbox" id="showpass" onclick="showPasswords('showpass', ['password']);">
                <label class="form-check-label" for="showpass">Show Password</label>
            </div>
            <div class="d-flex align-items-center justify-content-between mt-1 mb-0">
                <a class="float-end" href="">Forgot Password?</a>
                
                <button type="submit" name="btn_login" id="btn_login" class="btn btn-primary"><i class="fas fa-sign-in"></i> Login</button>
            </div>
        </form>
    </div>
    <div class="card-footer text-center py-3">
        <div class="small">Online Wildlife Permitting and Management System</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-extra'); ?>
<script type="text/javascript">
    function disableSubmitBtn(btn) {
        document.getElementById(btn).disabled = true;
        document.getElementById(btn).innerHTML = '<i class="fas fa-sign-in"></i>  Logging in...';
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\owpms-laravel11\resources\views/auth/login.blade.php ENDPATH**/ ?>