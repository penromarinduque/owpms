

<?php $__env->startSection('title'); ?>
Add New LTP Requirement
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-ltprequirements'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Add New LTP Requirement</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('ltprequirements.index')); ?>">LTP Requirements</a></li>
        <li class="breadcrumb-item active">Add New</li>
    </ol>
    <div class="card mb-4">
    	<div class="card-header">
            <div class="float-end">
                
                <a href="<?php echo e(route('ltprequirements.index')); ?>" class="btn btn-sm btn-danger">Back</a>
            </div>
            <i class="fas fa-plus-square me-1"></i>
            Add New LTP Requirement here
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('ltprequirements.store')); ?>" onsubmit="disableSubmitButton('btn_save');">
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                	<div class="col-sm-6">
                		<label for="requirement_name" class="form-label">Requirement Name</label>
	                    <input type="text" class="form-control" name="requirement_name" id="requirement_name" value="<?php echo e(old('requirement_name')); ?>">
	                    <?php $__errorArgs = ['requirement_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                    <small class="text-danger"><?php echo e($message); ?></small>
	                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                    <div class="col-sm-6">
                		<label class="form-label">Is mandatory?</label><br>
	                    <input type="radio" name="is_mandatory" id="is_mandatory_yes" value="1">
                        <label for="is_mandatory_yes" class="form-label">YES</label>&nbsp;&nbsp;
                        <input type="radio" name="is_mandatory" id="is_mandatory_no" value="0">
                        <label for="is_mandatory_no" class="form-label">NO</label>
	                    <?php $__errorArgs = ['is_mandatory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                    <small class="text-danger"><?php echo e($message); ?></small>
	                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                </div>
                <button type="submit" id="btn_save" class="btn btn-primary btn-block float-end">Save</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\owpms-laravel11\resources\views/admin/maintenance/ltprequirements/create.blade.php ENDPATH**/ ?>