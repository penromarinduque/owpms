

<?php $__env->startSection('title'); ?>
Edit LTP Requirement
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-ltprequirements'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Edit LTP Requirement</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('ltprequirements.index')); ?>">LTP Requirements</a></li>
        <li class="breadcrumb-item active">Edit</li>
    </ol>
    <div class="card mb-4">
    	<div class="card-header">
            <div class="float-end">
                
                <a href="<?php echo e(route('ltprequirements.index')); ?>" class="btn btn-sm btn-danger">Back</a>
            </div>
            <i class="fas fa-edit me-1"></i>
            Edit LTP Requirement here
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('ltprequirements.update', [$ltprequirement->id])); ?>" onsubmit="disableSubmitButton('btn_update');">
                <?php echo csrf_field(); ?>
                <?php if(!empty($ltprequirement)): ?>
                <div class="row mb-3">
                	<div class="col-sm-5">
                		<label for="requirement_name" class="form-label">Requirement Name</label>
	                    <input type="text" class="form-control" name="requirement_name" id="requirement_name" value="<?php echo e($ltprequirement->requirement_name); ?>">
	                    <?php $__errorArgs = ['requirement_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                    <small class="text-danger"><?php echo e($message); ?></small>
	                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                	<div class="col-sm-1"></div>
                    <div class="col-sm-3">
                		<label class="form-label">Is mandatory?</label><br>
	                    <input type="radio" name="is_mandatory" id="is_mandatory_yes" value="1" <?php echo e(($ltprequirement->is_mandatory==1) ? 'checked' : ''); ?>>
                        <label for="is_mandatory_yes" class="form-label">YES</label>&nbsp;&nbsp;
                        <input type="radio" name="is_mandatory" id="is_mandatory_no" value="0" <?php echo e(($ltprequirement->is_mandatory==0) ? 'checked' : ''); ?>>
                        <label for="is_mandatory_no" class="form-label">NO</label>
	                    <?php $__errorArgs = ['is_mandatory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                    <small class="text-danger"><?php echo e($message); ?></small>
	                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                	<div class="col-sm-3">
                		<label class="form-label">Status</label><br>
	                    <input type="radio" name="is_active_requirement" id="is_active_requirement_yes" value="1" <?php echo e(($ltprequirement->is_active_requirement==1) ? 'checked' : ''); ?>>
                        <label for="is_active_requirement_yes" class="form-label">Active</label>&nbsp;&nbsp;
                        <input type="radio" name="is_active_requirement" id="is_active_requirement_no" value="0" <?php echo e(($ltprequirement->is_active_requirement==0) ? 'checked' : ''); ?>>
                        <label for="is_active_requirement_no" class="form-label">Inactive</label>
	                    <?php $__errorArgs = ['is_active_requirement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                    <small class="text-danger"><?php echo e($message); ?></small>
	                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                	</div>
                </div>
                <button type="submit" id="btn_update" class="btn btn-primary btn-block float-end">Save Changes</button>
                <?php else: ?>
                <center><h2 class="text-danger">No record found!</h2></center>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\owpms-laravel11\resources\views/admin/maintenance/ltprequirements/edit.blade.php ENDPATH**/ ?>