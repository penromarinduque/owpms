

<?php $__env->startSection('title'); ?>
Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-dashboard'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href=""></a></li>
        <!-- <li class="breadcrumb-item active">Sidenav Light</li> -->
    </ol>
    <div class="card mb-4">
        <div class="card-body">
            <!-- This page is an example of using the light side navigation option. By appending the
            <code>.sb-sidenav-light</code>
            class to the
            <code>.sb-sidenav</code>
            class, the side navigation will take on a light color scheme. The
            <code>.sb-sidenav-dark</code>
            is also available for a darker option. -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\owpms-laravel11\resources\views/dashboard.blade.php ENDPATH**/ ?>