<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubBreeder extends Model
{
    //
}
